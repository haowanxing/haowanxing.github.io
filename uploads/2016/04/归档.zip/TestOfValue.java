/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testofvalue;

/**
 *
 * @author Anthony <york_mail@qq.com>
 */
public class TestOfValue {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a = 10, b[] = {1,2,3};
        A obj = new A("Hello");
        ch1(a);
        System.out.println(a);
        System.out.println("原数组:");
        prt2(b);
        ch2(b);
        System.out.println("改变后的数组:");
        prt2(b);
        ch1(b[1]);  //测试数组中的一个值  
        System.out.println("改变b[1]后的数组:"); 
        prt2(b);
        ch3(obj);
        System.out.println(obj.value);
        ch4(obj.value);        
        System.out.println(obj.value);
    }
    public static void ch1(int v) {
        ++v;
    }
    public static void ch2(int v[]) {
        for(int i=0;i<v.length;i++){
            v[i]++;
        }
    }
    public static void ch3(A a) {
        a.value += " World!";
    }
    public static void ch4(String str) {
        str += " String!";
    }
    public static void prt2(int v[]) {
        for(int i=0;i<v.length;i++){
            System.out.println("v["+i+"]:"+v[i]);
        }
    }
    
}
class A {
    public String value;
    A(String value) {
        this.value = value;
    }
}

<?php
/**
 * Created by PhpStorm.
 * User: anthony
 * Date: 16/1/20
 * Time: 上午11:46
 */
header("Content-type:text/html;charset=utf-8");
function ch1($v) {  //按值传递
  $v++;
}
function ch2(&$v) { //传引用
  $v++;
}
function ch3($ov) { //传对象的值
  $ov = " Changed! ch3";
}
function ch4($o) {  //传对象
  $o->value = " Changed! ch4";
}
function ch5($v) {  //改变数组
  for($i=0;$i<sizeof($v);$i++){
    $v[$i]++;
  }
}
function ch6(&$v) {  //改变数组 传引用
  for($i=0;$i<sizeof($v);$i++){
    $v[$i]+=10;
  }
}
$a = 10;
$arr = Array(1,2,3);
echo "\$a=".$a."<br>";
ch1($a);
echo "ch1():  ".$a."<br>";
ch2($a);
echo "ch2():  ".$a."<br>";
echo "创建对象:";
$obj = new A();
ch3($obj->value);
echo "ch3():  ";
echo $obj->value."<br>";
ch4($obj);
echo "ch4():  ";
echo $obj->value."<br>";
print_r($arr);
echo "<br>";
ch5($arr);
print_r($arr);
echo "<br>";
ch6($arr);
print_r($arr);
echo "<br>";

class A {
  public $value = "I'm A's value";
  public function __construct()
  {
    echo $this->value."<br>";
  }
}
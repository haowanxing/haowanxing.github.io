//
//  main.c
//  TestOfVlaue
//
//  Created by anthony on 16/4/16.
//  Copyright © 2016年 Anthony. All rights reserved.
//

#include <stdio.h>
//C语言测试
void prt1(int v) {
    printf("方法内执行后的结果：%d\n",v);
}
void prt2(int v[],short int len) {
    for (int i=0; i<len; i++) {
        printf("a[%d]:%d\n",i,v[i]);
    }
}
void ch1(int v) {   //按值传递
    ++v;
    prt1(v);
}
void ch2(int *v) {  //按地址(指针)传递
    ++(*v);
    prt1(*v);
}
//void ch3(int &v) {  //引用传递 C里面木有&（引用）C++中可用，底层还是指针
//    ++v;
//    prt1(*v);
//}
void ch4(int v[],short int len) {   //改变数组的值
    for (int i=0; i<len; i++) {
        v[i]++;
    }
}
void test1(int v) {     //测试整型变量
    printf("测试单个值：类型：int,值为：%d\n",v);
    ch1(v);
    printf("执行ch1()的结果：%d\n",v);
    ch2(&v);
    printf("执行ch2()的结果：%d\n\n",v);
}
void test2(int v[],short int len) {     //测试整型数组
    printf("测试数组：类型：int,值为：\n");
    prt2(v, len);
    ch4(v,len);
    printf("方法内执行后的结果：\n");
    prt2(v, len);
    printf("\n");
}
int main(int argc, const char * argv[]) {
    int a = 10;
    int b[] = {1,2,3};
    test1(a);       //测试变量a++
    test2(b, 3);    //测试数组b各元素++
    test1(b[0]);    //测试数组b[0]++
    return 0;
}
